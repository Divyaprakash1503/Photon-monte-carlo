#include <iostream>
#include <cstdlib>
#include <bits/stdc++.h>

using namespace std;
void RN()
{
    int n = 50;
    long double Randnum[n];
   // srand(time(0)); /* Activate this to get new set of random numbers every time.*/
    for (int i = 0; i < n; i++)
        Randnum[i] = ((long double)rand()) / RAND_MAX ;
    for (int j =0; j<n;j++)
        cout << Randnum[j]<<endl;
}
int main()
{
    RN();
}
