#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <random>  // For better random number generation

using namespace std;

const double PI = 3.14159265358979323846;

// Random number generator setup
std::mt19937 rng(static_cast<unsigned int>(time(0)));
std::uniform_real_distribution<double> uniform_dist(0.0, 1.0);

// Generate a random double in the range [0, 1)
double rand_double()
{
    return uniform_dist(rng);
}

// Photon structure
struct Photon
{
    double x, y, z;   // Position components
    double u, v, w;   // Direction cosines
    double energy;
};

// Generate a random direction uniformly over the sphere
void random_direction(double& u, double& v, double& w)
{
    double z = 2.0 * rand_double() - 1.0;       // Cosine of polar angle phi
    double t = 2.0 * PI * rand_double();        // Azimuthal angle theta

    double r = sqrt(1.0 - z * z);               // Sine of phi

    u = r * cos(t);
    v = r * sin(t);
    w = z;
}

int main()
{
    // Simulation parameters
    const double tol = 0.001;
    const double kappa = 1.0;       // Absorption coefficient
    const double cube_size = 1.0;   // Size of the cube in all dimensions

    // Initialize photon at random position within the cube
    Photon photon;
    photon.x = rand_double() * cube_size;
    photon.y = rand_double() * cube_size;
    photon.z = rand_double() * cube_size;
    photon.energy = 1.0;            // Initial energy

    random_direction(photon.u, photon.v, photon.w);

    cout << "Starting position: (" << photon.x << ", " << photon.y << ", " << photon.z << ")" << endl;

    // Open file to record photon path
    ofstream outfile("single_photon.txt");
    if (!outfile.is_open())
    {
        cerr << "Error opening file!" << endl;
        return 1;
    }

    // Write initial position to file
    outfile << "Photon,0," << photon.x << "," << photon.y << "," << photon.z << "," << photon.energy << endl;

    int step_count = 0;

    while (photon.energy > tol)
    {
        // Sample step size from exponential distribution
        double step_size = -log(rand_double()) / kappa;

        // Update position
        photon.x += step_size * photon.u;
        photon.y += step_size * photon.v;
        photon.z += step_size * photon.w;

        // Check for boundary reflections with specular conditions
        if (photon.x <= 0.0)
        {
            photon.x = -photon.x;  // Reflect and ensure it's within bounds
            photon.u = -photon.u;
        }
        else if (photon.x >= cube_size)
        {
            break; // Reflect back into the cube

        }

        if (photon.y <= 0.0)
        {
            photon.y = -photon.y;  // Reflect and ensure it's within bounds
            photon.v = -photon.v;
        }
        else if (photon.y >= cube_size)
        {
            photon.y = - photon.y; // Reflect back into the cube
            photon.v = -photon.v;
        }

        if (photon.z <= 0.0)
        {
            photon.z = -photon.z;  // Reflect and ensure it's within bounds
            photon.w = -photon.w;
        }
        else if (photon.z >= cube_size)
        {
            photon.z =  - photon.z; // Reflect back into the cube
            photon.w = -photon.w;
        }

        // Update energy considering absorption
        double absorption_prob = 1.0 - exp(-kappa * step_size);
        photon.energy *= (1.0 - absorption_prob);

        step_count+=0.01*step_count;

        // Write current state to file
        outfile << "Photon," << step_count << "," << photon.x << "," << photon.y << "," << photon.z << "," << photon.energy << endl;

        // Optionally, print to console
        cout << "Step " << step_count << ": Position=(" << photon.x << ", " << photon.y << ", " << photon.z << "), Energy=" << photon.energy << endl;
    }

    outfile.close();
    cout << "Simulation completed in " << step_count << " steps." << endl;

    return 0;
}
