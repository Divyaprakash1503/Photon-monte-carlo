#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime>

const double PI = 3.14159265358979323846;

// Random number generator in the range [0, 1)
double rand_double()
 {
    return rand() / (RAND_MAX + 1.0);
}

// Generate a random number in a given range [min, max]
double rand_range(double min, double max)
{
    return min + (max - min) * rand_double();
}

// Photon structure
struct Photon {
    double x, y, z;
    double weight;
};

// Simulate photon transport
void transport_photon(Photon& photon, double absorption_prob, double scattering_prob)
 {
    while (photon.weight > 0.001)
        {
        // Step size determined by random exponential distribution
        double step_size = -log(rand_double());

        // Update photon position
        photon.x += step_size * (2 * rand_double() - 1);
        photon.y += step_size * (2 * rand_double() - 1);
        photon.z += step_size * (2 * rand_double() - 1);

        // Determine if photon is absorbed or scattered
        double event = rand_double();

        if (event < absorption_prob) {
            // Photon absorbed
            photon.weight = 0;
        } else if (event < absorption_prob + scattering_prob) {
            // Photon scattered
            photon.weight *= 0.9; // Assume some weight loss upon scattering

            // Randomly change direction (isotropic scattering)
            double theta = acos(2 * rand_double() - 1);
            double phi = 2 * PI * rand_double();

            photon.x += sin(theta) * cos(phi);
            photon.y += sin(theta) * sin(phi);
            photon.z += cos(theta);
        } else {
            // Photon continues without interaction
        }
    }
}

int main()
{
    srand(static_cast<unsigned int>(time(0))); //new random number for every iteration

    const int n = 100;
    const double absorption_prob = 0.1;
    const double scattering_prob = 0.2;

    for (int i = 0; i < n; ++i)
        {
        // Initialize photon with random position in a specified range (e.g., -10 to 10)
        Photon photon = {rand_range(0.0, 1.0), rand_range(0.0, 1.0), rand_range(0.0, 1.0), 1.0};
        transport_photon(photon, absorption_prob, scattering_prob);

        // Output the final position and weight of the photon
        std::cout << "Photon " << i + 1 << ": Position ("<< photon.x << ", " << photon.y << ", " << photon.z<< "), Final Weight: " << photon.weight << std::endl;
         }

    return 0;
}
