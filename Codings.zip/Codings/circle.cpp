#include <iostream>
#include <cstdlib>
#include <cmath>
#include <ctime>

using namespace std;

int main() {
    // Set up random number generator
    srand(static_cast<unsigned>(time(0)));

    // Circle parameters
    double radius = 1.0; // Circle with radius 1
    double Areaofsquare=radius*radius;
    float Actualans = (22.0/7.0)*radius*radius;
    cout << Actualans<<endl;
    int n = 1000; // Total number of points to generate
    int pointsInsideCircle = 0; // Points that fall inside the circle

    // Generate points and count how many fall inside the circle
    for (int i = 0; i < n; ++i) {
        double x = static_cast<double>(rand()) / RAND_MAX * radius;
        double y = static_cast<double>(rand()) / RAND_MAX * radius;

        // Check if the point is inside the circle
        if (x * x + y * y <= radius * radius) {
            pointsInsideCircle++;

        }
    }
    cout<< pointsInsideCircle<<endl;

    // Calculate area using the ratio of points inside the circle
    double areaEstimate = Areaofsquare*4*( static_cast<double>(pointsInsideCircle) / n);

    // Output the result
    cout << "Estimated area of the circle: " << areaEstimate << endl;
     double error = abs ( areaEstimate- Actualans);
      cout << "error:"<<error;


    return 0;
}
